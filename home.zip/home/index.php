<?php
include_once 'connect.php';
session_start();
if(!isset($_SESSION['usr_name']))
{
	header("Location: ../login/index.php");

}
else
{
?>
<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8"/>
    <title>ITV BLAZON</title>
	 <script src="sliderengine/jquery.js"></script>
    <script src="sliderengine/amazingslider.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
    <script src="sliderengine/initslider-1.js"></script>
	 <script src="http://code.jquery.com/jquery-3.0.0.min.js"></script>
    <script src="quotespinner.js"></script>
    
    
    </head>
<body>
<div style="width:100%; height:650px; background:url('1.jpg');  background-repeat:no-repeat; background-attachment:fixed;">
<img src="itv2.png" width="20%" height="20%" style="margin-left:-2px;">
<img src="blazon2.png" width="20%" height="18%" style="margin-left:803px; position:absolute;">
<div style="width:auto; color:white; background:; height:50px; position:absolute; margin-left:390px; margin-top:-80px; font-size:25px; font-family:arial;">
<ul>
<a href="alert/alertlogin.php"><li>Alert!</li></a>
<a href="#"><li>About Us</li></a>
<a href="#club"><li>Explore</li></a>
<a href="#"><li>Contact Us</li></a>

<a href="logout.php"><li>Logout</li></a>
</ul>

</div>


<img src="pic.png" width="150px" height="150px" style="margin-left:850px; margin-top:90px; position:absolute;">
<h2 style="color:white;margin-left:1155px; position:absolute;margin-top:-0.1px;font-size:25px;">Kreiva<br><span style="font-size:15px; text-align:center;color:#106606; margin-left:-5px;">21st Oct-2016</span><br><a href="#"><img src="jp.png" width="25px" height="25px"style="margin-top:5px;margin-left:25px;"></a></h2>

<div style="width:40%; height:250px; background:none; margin-left:400px; margin-top:200px; border:2px solid #4BE5FA">



<div class="quotes">
      
      <div class="quote-contain">
        <div class="quote-rotate">
          <p>&ldquo;On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee.&rdquo;</p>
        </div>
        <div class="quote-rotate">
          <p>&ldquo;But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness. . &rdquo;</p>
        </div>
        <div class="quote-rotate">
          <p>&ldquo;Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure.  .&rdquo;</p>
        </div>
        <div class="quote-rotate">
          <p>&ldquo;The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words. . .&rdquo;</p>
        </div>
		
      </div>
     
    </div><script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-36251023-1']);
  _gaq.push(['_setDomainName', 'jqueryscript.net']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</div>
<div class="quote-dots"></div>
 </div>
 
 <div style="width:100%; height:500px; background:url('5.jpg'); background-repeat:no-repeat; margin-top:;" id="house">
 
<img src="house.png" width="300px" height="480px" style="margin:10px; margin-left:50px;">
<a href="#"><img src="h1.png" width="190px" height="60px" style="margin-top:58px; margin-left:-158px; position:absolute;"></a>
<a href="#"><img src="h2.png" width="190px" height="60px" style="margin-top:118px; margin-left:-355px; position:absolute;"></a>
<a href="#"><img src="h3.png" width="190px" height="60px" style="margin-top:175px; margin-left:-150px; position:absolute;"></a>
<a href="#"> <img src="h4.png" width="190px" height="60px" style="margin-top:240px; margin-left:-360px; position:absolute;"></a>

<div style="width:750px; height:400px; float:right; background:url('frame.jpg');; position:relative; margin-top:50px; margin-right:20px;">
<div style="width:600px; height:300px; background:url('6.png'); margin:60px; margin-left:80px;margin-top:50px;" id="animat">
</div>
 
 </div>
 
 
<div style="width:100%; height:600px; background:url('BLAZON13.jpg'); background-repeat:no-repeat; margin-top:; " id="club">
<div style="width:300px;height:100px; margin-left:50px; margin-top:50px; position:absolute;">
<a href="../cultural/index.php"><img src="cult.png" width="300px" height="100px;"></a>

</div>

<div style="width:300px;height:100px; margin-left:420px; margin-top:20px; position:absolute;">
<a href="#"><img src="dc.png" width="150px" height="160px;"></a>
</div>

<div style="width:300px;height:100px; margin-left:600px; margin-top:10px; position:absolute;">
<a href="../photo/index.php"><img src="pc.png" width="340px" height="180px;"></a>
</div>

<div style="width:300px;height:100px; margin-left:1000px; margin-top:10px; position:absolute;">
<a href="#"><img src="lc.png" width="280px" height="180px;"></a>
</div>

<div style="width:300px;height:100px; margin-left:15px; margin-top:210px; position:absolute;">
<a href="../bus/index.php"><img src="tc2.png" width="250px" height="200px;"></a>
</div>

<div style="width:300px;height:100px; margin-left:355px; margin-top:193px; position:absolute;">
<a href="../new mess/index.php"><img src="mc.png" width="400px" height="80px;"></a>
</div>

<div style="width:300px;height:100px; margin-left:830px; margin-top:193px; position:absolute;">
<a href="#"><img src="ac.png" width="150px" height="80px;"></a>
</div>

<div style="width:300px;height:100px; margin-left:1000px; margin-top:205px; position:absolute;">
<a href="../new mess/index.php"><img src="mc2.png" width="300px" height="200px;"></a>
</div>

<div style="width:300px;height:100px; margin-left:335px; margin-top:273px; position:absolute;">
<a href="#"><img src="drc.png" width="280px" height="160px;"></a>
</div>

<div style="width:300px;height:100px; margin-left:680px; margin-top:273px; position:absolute;">
<a href="../game/index.php"><img src="gc.png" width="280px" height="160px;"></a>
</div>

<div style="width:300px;height:100px; margin-left:px; margin-top:430px; position:absolute;">
<a href="#"><img src="dc2.png" width="150px" height="160px;"></a>
</div>

<div style="width:300px;height:100px; margin-left:160px; margin-top:430px; position:absolute;">
<a href="../music club/index.php"><img src="mc3.png" width="220px" height="160px;"></a>
</div>

<div style="width:300px;height:100px; margin-left:450px; margin-top:440px; position:absolute;">
<a href="#"><img src="sc.png" width="340px" height="150px;"></a>
</div>

<div style="width:300px;height:100px; margin-left:840px; margin-top:440px; position:absolute;">
<a href="#"><img src="cc.png" width="140px" height="140px;"></a>
</div>

<div style="width:300px;height:100px; margin-left:1010px; margin-top:440px; position:absolute;">
<a href="#"><img src="hec.png" width="285px" height="140px;"></a>
</div>

</div>



<input class="modal-state" id="modal-1" type="checkbox" />
<div class="modal">
  <label class="modal__bg" for="modal-1"></label>
  <div class="modal__inner">
    <label class="modal__close" for="modal-1"></label>
      <h1 style="color:white; font-style:italic; margin-top:-5px;">
	Feedback</h1>
	<h3 style="width:100%; height:5px; background:orange; margin-top:-25px;"></h3>
    <form action="#" method="post">
	<input type="text" name="name" placeholder="&nbsp;&nbsp;Enter your name" required="required" style="width:300px; border:2px solid #686E73;
	height:35px; background:white; border-radius:15px; text-decoration:none; font-stretch:10px; padding:5px;">
  <br><input type="text" name="id" placeholder="&nbsp;&nbsp;Enter your ID" style="width:300px; border:2px solid #686E73;
	height:35px; background:white; border-radius:15px; margin-top:8px; text-decoration:none; font-stretch:10px; padding:5px;">
  <br><textarea name="comments" placeholder="&nbsp;&nbsp;Leave Comments Here..." 
			style="width:500px; height:95px; background:white; text-indent;10px;  
			border:2px solid #686E73;border-radius:15px; margin-top:8px; padding:5px; font-stretch:10px;"></textarea>
  <input type="submit" name="submit" style="value:none; background:transparent url('red.png');
  width:50px; height:50px; border:none; color:transparent; margin-top:-20px; margin-left:-5px;">
  </form>
  
		</div>
		</div>
		
		<div style="width:100%; height:250px; background:url('1.jpg'); margin-top:-20px;">
		<div style="width:1250px; height:210px; background:url('footer3.png'); margin-left:40px; margin-top:20px; position:absolute; ">
		<h2 style="color:white;position:absolute; margin-left:100px; margin-top:10px; font-family:Aparajita;">
		<img src="clubs.png" height="35px" width="100px" style="margin-top:10px;"></h2>
		<br><br>
		<ul style="list-style-type:none; padding:1px;  margin-left:70px;" id="foot">
		<li>Music Club</li>
		<li>Dance Club</li>
		<li>Drama Club</li>
		<li>Design Club</li>
		<li>Literary Club</li>
		<li>Debate Club</li>
		</ul>
		<ul style="list-style-type:none; padding:1px; margin-top:-108px; margin-left:0px; position:absolute;" id="foot2">
		<li>Photography Club</li>
		<li>Coding Club</li>
		<li>Art Club</li>
		<li>Gaming Club</li>
		
		</ul>
		<h2 style="color:white;position:absolute; margin-left:310px; margin-top:-169px; font-family:Aparajita;">
		<img src="committee.png" height="35px" width="120px;"></h2>
		<ul style="list-style-type:none; padding:1px; margin-top:-108px; margin-left:0px; position:absolute;" id="foot3">
		<li>Cultural Committee</li>
		<li>Mess Committee</li>
		<li>Transport Committee</li>
		<li>Sports Committee</li>
		<li>HEC Committee</li>
		<li>Maintanance Committee</li>
		</ul>
		<div style="margin-left:500px; margin-top:-150px;">
		<img src="bl.png" width="270px" height="130px">
		</div>
		<h2 style="color:white;position:absolute; margin-left:810px; margin-top:-150px; font-family:Aparajita;">
		<img src="link.png" height="35px" width="100px;"></h2>
		<ul style="list-style-type:none; padding:1px; margin-top:-108px; margin-left:0px; position:absolute;" id="foot4">
		<li>IIIT Vadodara</li>
		<li>FB-IIITV</li>
		<li>Quora Page</li>

		</ul>
		<div style="margin-left:820px; margin-top:-150px; background:;   position:absolute; width:400px; height:190px;">
		<img src="footcn.png" width="45px" height="180px" style="margin-left:150px;">
		<div style="float:right; width:200px; height:40px;  ">
		<img src="mail.png" width="20px" height="20px" style="margin-left:50px;">
		<h5 style="margin-top:-20px; margin-left:25px; float:right;color:white">blazon.itv@gmail.com</h5><br>
		<img src="feed1.png" width="20px" height="20px" style="margin-top:-23px;margin-left:50px;">
		<h5 style="margin-top:-21px; margin-left:25px;float:right; color:white;">7567775854&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</h5>
		</div>
		<h2 style="margin-left:260px; margin-top:-130px; font-family:Aldhabi; color:white; font-style:italic; font-size:40px;">follow Us</h2>
		<div style=" margin-top:-45px;">
		<img src="fb.gif" style="margin-left:210px; margin-top:-50px;"><img src="google.gif">
		<img src="twit.png"> </div>
		</div>
		</div>
		</div>
</body>
</html>

<?php } ?>





