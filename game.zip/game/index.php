


<?php
require("db.php");
if(isset($_POST['submit'])){
$name = $_POST['name'];
$name1 = $_POST['name1'];
$comments = $_POST['message'];

{
mysqli_query($con, "INSERT INTO comments(name,name1,comments,clubs_comm_id) VALUES('$name','$name1','$comments','GM')");

}

}
mysqli_close($con);
?>




<html>
    <head>
    	<title>itks_project</title>
        <link href="style_game.css" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css">
    </head>
    
        
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">

    <body>
               
        <div id="screen1">
            <img class="mySlides w3-animate-left" src="6(a).jpg" style="width:92%">
            <img class="mySlides w3-animate-left" src="6(b).jpg" style="width:92%">
            <img class="mySlides w3-animate-left" src="6(c).jpg" style="width:92%">       
        </div>

        <div id="screen2">
            <div id="back">
                <div id="icon1">
                    <div id="shade1">
                        <a href="#"><b>NOTIFICATIONS</b></a>
                    </div>
                </div>
                 <div id="icon2">
                    <div id="shade2">
                       <div id="shade"> <a href="#"><b>MEMBERS</b></a></div>
                    </div>
                </div>
                 <div id="icon3">
                    <div id="shade3">
                        <a href="alert/alertlogin.php"><b>ALERT</b></a>
                    </div>
                </div>
                 <div id="icon4">
                    <div id="shade4">
                        <a href="#"><b>QUERY</b></a>
                    </div>
                </div>
            </div>

        </div>

        <div id="screen3">
            <img class="mySlides2 w3-animate-right" src="6(c).jpg" style="width:90%">
            <img class="mySlides2 w3-animate-right" src="6(a).jpg" style="width:90%">
            <img class="mySlides2 w3-animate-right" src="6(b).jpg" style="width:90%">       
        </div>

        <div id="myModal" class="modal">
            <div class="modal-content">
               <span class="close">×</span>
               <div class="left">
                   <img src="pro.png" alt="Fjords" width="300" height="200">
                 <div class="desc">SAI TEJA<br>Secretary<br> Gaming Club</div>
               </div>

               <div class="left">
                   <img src="pro.png" alt="Forest" width="300" height="200">
                 <div class="desc">Alizey Jalil<br>Joint-Secretary<br> Gaming Club</div>
               </div>               
            </div>
        </div>

    <script>
        var myIndex = 0;
        var myIndex1=0;
        carousel();
        carousel2();
        function carousel() {
        var i;
        var x = document.getElementsByClassName("mySlides");
        for (i = 0; i < x.length; i++) {
          x[i].style.display = "none";
        }
        myIndex++;
        if (myIndex > x.length) {myIndex = 1}
        x[myIndex-1].style.display = "block";
        setTimeout(carousel, 5000);
        }

        function carousel2() {
        var i;
        var x = document.getElementsByClassName("mySlides2");
        for (i = 0; i < x.length; i++) {
          x[i].style.display = "none";
        }
        myIndex1++;
        if (myIndex1 > x.length) {myIndex1 = 1}
        x[myIndex1-1].style.display = "block";
        setTimeout(carousel2, 5000);
        }

        // Get the modal
        var modal = document.getElementById('myModal');

// Get the button that opens the modal
        var btn = document.getElementById("shade2");

// Get the <span> element that closes the modal
        var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal
        btn.onclick = function() {
            modal.style.display = "block";
        }

// When the user clicks on <span> (x), close the modal
        span.onclick = function() {
            modal.style.display = "none";
        }

// When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }

    </script>

        <div id="logo">
        </div>
                
    </body>
</html>

