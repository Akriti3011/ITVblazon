
<?php
session_start();

?>


<?php
require("db/db.php");
if(isset($_POST['submit'])){
$name = $_POST['name'];
$name1 = $_POST['name1'];
$comments = $_POST['comments'];

{
mysqli_query($con, "INSERT INTO comments(name,name1,comments,clubs_comm_id) VALUES('$name','$name1','$comments','CC')");

}

}
mysqli_close($con);
?>



<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>IIITV BUS</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
      
	

<link href="tooplate_style.css" rel="stylesheet" type="text/css" />

<script type="text/JavaScript" src="js/jquery-1.6.3.js"></script> 

<link rel="stylesheet" type="text/css" href="css/ddsmoothmenu.css" />

<script type="text/javascript" src="js/ddsmoothmenu.js">


</script>

<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "tooplate_menu", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>

<link rel="stylesheet" href="css/slimbox2.css" type="text/css" media="screen" /> 
<script type="text/JavaScript" src="js/slimbox2.js"></script> 

<link rel="stylesheet" href="css/nivo-slider.css" type="text/css" media="screen" />

</head>
<body>

<div id="tooplate_header">
    <a href="index.html" class="sitetitle"><span style="font-size:60px; font-family:French Script MT; 
	color:white;">
	Transport</span>&nbsp;&nbsp;&nbsp;&nbsp;
	<span style="font-size:40px; font-family:Bauhaus 93; color:white;">
	Committee</span>
	
	</a>  
    <div id="tooplate_menu" class="ddsmoothmenu">
        <ul>
            <li><a href="../home/index.php" >Home</a></li>
            <li><a href="alert/alertlogin.php">Alert!</a>
                
            </li>
            <li><a href="#feed" >Feedback</a>
                
            </li>
            <li><a href="#about">About</a></li>   

            <li class="last"><a href="#contact" class="last">Contact</a></li>
        </ul>
        <br style="clear: left" />
    </div> <!-- end of tooplate_menu -->      
</div> <!-- END of header -->
<div id="tooplate_slider_wrapper">
    <div id="tooplate_slider">
    	<div class="slider-wrapper theme-default">
            <div id="slider" class="nivoSlider">
                <img src="images/slider/01.jpg" alt="" title="#caption1" />
                <img src="images/slider/02.jpg" alt="" title="#caption2" />
                 <img src="images/slider/03.jpg" alt="" title="#caption3" />
                <img src="images/slider/04.jpg" alt="" title="#caption4" /> 
				<img src="images/slider/05.jpg" alt="" title="#caption5" /> 
				<img src="images/slider/06.jpg" alt="" title="#caption6" /> 
				<img src="images/slider/03.jpg" alt="" title="#caption7" /> 				
            </div>
            <div id="caption1" class="nivo-html-caption">
            	<h1>Monday</h1>
                <p></p>
				</div>
            <div id="caption2" class="nivo-html-caption">
                <h1>Tuesday</h1>
                <p></p></div>
            <div id="caption3" class="nivo-html-caption">
                <h1>Wednesday</h1>
                <p></p></div>
				<div id="caption4" class="nivo-html-caption">
            	<h1>thursday</h1>
                <p></p>
				</div>
            <div id="caption5" class="nivo-html-caption">
                <h1>Friday</h1>
                <p></p></div>
            <div id="caption6" class="nivo-html-caption">
                <h1>Saturday</h1>
                <p></p></div>
				<div id="caption7" class="nivo-html-caption">
                <h1>Sunday</h1>
                <p></p></div>
        </div>
        <div class="button_box">
        	
        </div>
        <script type="text/javascript" src="js/jquery-1.6.3.min.js"></script>
		<script type="text/javascript" src="js/jquery.nivo.slider.pack.js"></script>
        <script type="text/javascript">
        $(window).load(function() {
            $('#slider').nivoSlider({
			effect: 'fade',
			controlNav: true, // 1,2,3... navigation
            directionNav: false,
			animSpeed: 1200, // Slide transition speed
	        pauseTime: 3000, // How long each slide will show
			});
        });
        </script>	
    </div> <!-- END of slider -->
</div>
    <div id="tooplate_main">
    	<div id="home_about">
        	<h1 style="color:white; background-color:#1D4855; height:180px; font-size:14px;">
			<img src="images/aboutbc.png" width="20%" style="float:left; margin-top:40px;">
			<div style="width:900px; margin-left:300px;padding:20px;" id="about">
			<p>The B.Tech,PhD programs are residential programs, and therefore, IIIT Vadodara provides residential
			facilities for all students.Indian Institute of Information Technology Vadodara is an institute 
			established by the Government of India under Public Private Partnership (PPP) mode. The partners
			in this project are Government of India,</p> 
			</div>
			</h1>
			</div>
			<div style="width:350px; height:200px; background:#2884C4; border-radius:25px;
			border-top:4px solid white; margin-left:50px; margin-top:-60px;">
			<img src="images/time.png" width="100px" height="100px" align="center" style="margin-left:115px; margin-top:20px;">
			<h1 style="color:white; font-style:italic; text-align:center;margin-top:10px;">Bus Schedule</h1>
			<div style="width:250px; height:155px; background:#08304C; margin-left:50px; margin-top:-20px;
			border:2px solid orange;
			border-radius: 25px 25px 5px 5px;">
			<p style="color:white; text-align:center; padding:4px; margin-top:25px;">
			The B.Tech,PhD programs are residential programs, and therefore, IIIT Vadodara provides residential
			facilities for all students.<br><br>
			<a href="bus1.pdf" target="_blank" style="font-style:italic;text-decoration:none; color:red;">
			<img src="images/arrow.png" width="50px" height="50px" style="margin-left:90px;"></a>
			</p>
			</div>
			</div>
			</div>
			
			<div style="width:350px; height:200px; background:#2884C4; border-radius:25px;
			border-top:4px solid white; margin-left:500px; margin-top:-200px;">
			<img src="images/mem.png" width="100px" height="100px" align="center" style="margin-left:115px; margin-top:20px;">
			<h1 style="color:white; font-style:italic; text-align:center;margin-top:10px;">Members</h1>
			<div style="width:250px; height:150px; background:#08304C; margin-left:50px; margin-top:-20px;
			border:2px solid #E75421;
			border-radius: 25px 25px 5px 5px;">
			<p style="color:white; text-align:center; padding:4px; margin-top:25px;">
			To cordinate with students our committee is comprises of several members who look after the arrangements.. <br><br>
			<label class="btn2" for="modal-2" id="feed"><img src="images/arrow.png" width="50px" height="50px" style="margin-left:90px;"></label>
			</p>
			</div>
			</div>
			</div>
			
			<div style="width:350px; height:200px; background:#2884C4; border-radius:25px;
			border-top:4px solid white; margin-left:950px; margin-top:-200px;">
			<img src="images/noti.png" width="100px" height="100px" align="center" style="margin-left:115px; margin-top:20px;">
			<h1 style="color:white; font-style:italic; text-align:center;margin-top:10px;">Notifications</h1>
			<div style="width:250px; height:145px; background:#08304C; margin-left:50px; margin-top:-20px;
			border:2px solid #3EAF17;
			border-radius: 25px 25px 5px 5px;" >
			
			
			</div>
			</div>
				
			
			  <div style="width:99.9%;height:300px; background-image:url('images/cc.jpg');margin-top:140px; text-align:center;
		padding:2px;">
		<label class="btn" for="modal-1" id="feed">Feedback</label>
		</div>
		<div style="width:30px; height:250px; background:url('images/cont.jpg'); color:white; text-align:vertical; margin-top:-275px; border-radius:4px;" id="contact">
		</div>
		<div style="width:300px; height:250px; background:; margin-left:100px; margin-top:-200px;">
		<h2 style="color:white; text-align:center;">Yogi Edutransit Pvt Ltd</h2>
		<img src="loc1.png" width="25px" height="25px" style="margin-left:20px;margin-top:-15px;">
		<p style="color:white; margin-left:54px; margin-top:-25px;">
		 Address: R 15 Gold Plaza Shop No 3, ,<br> B/H D Mart, Sector 26 <br>Gandhinagar.382028
		<br><span style="color:white; font-size:120%;">Phone No.-xxxxxxx0920</span>
		
		</p>
		<img src="mail.png" width="25px" height="25px" style="margin-left:20px;margin-top:-5px;">
		<p style="color:white; margin-left:54px; margin-top:-25px;">
		yogiedutransit@gmail.com
		</p>
		</div>
		<div style="width:300px; height:250px; background:; margin-left:500px; margin-top:-255px;">
		<h2 style="color:white; text-align:center;">Bus Committee Enquiry</h2>
		<img src="loc1.png" width="25px" height="25px" style="margin-left:20px;margin-top:-15px;">
		<p style="color:white; margin-left:54px; margin-top:-25px;">
		 Address: IIIT Vadodara<br>GEC Block-09 IC Department,Sector 28 <br>Gandhinagar.382028
		<br><span style="color:white; font-size:120%;">Phone No.-83477734119</span>
		</p>
		<img src="mail.png" width="25px" height="25px" style="margin-left:20px; margin-top:-5px;">
		<p style="color:white; margin-left:54px; margin-top:-25px;">
		buscommittee@iiitvadodara.ac.in
		</p>
		</div>
       
	   <div style="width:300px; height:250px; background:; margin-left:950px; margin-top:-285px;">
		<img src="bus5.png">

		</div>
		<div style="width:400px; height:250px; background:; margin-left:870px; margin-top:-250px;">
		
		<iframe style="width:400px;height:250px; background:white;" src="logs.php" id="frame"></iframe>		
		
		
		
		</div>
	   </div> 


			
			
			
<input class="modal-state" id="modal-1" type="checkbox" />
<div class="modal">
  <label class="modal__bg" for="modal-1"></label>
  <div class="modal__inner">
    <label class="modal__close" for="modal-1"></label>
      <h1 style="color:white; font-style:italic; margin-top:-5px;">
	<img src="feed1.png" width="50px" height="50px">Feedback</h1>
	<h3 style="width:100%; height:5px; background:orange; margin-top:-25px;"></h3>
    <form action="#" method="post">
	<input type="text" name="name" placeholder="&nbsp;&nbsp;Enter your name" style="width:300px; border:2px solid #686E73;
	height:35px; background:white; border-radius:15px; text-decoration:none; font-stretch:10px; padding:5px;">
  <br><input type="text" name="id" placeholder="&nbsp;&nbsp;Enter your ID" style="width:300px; border:2px solid #686E73;
	height:35px; background:white; border-radius:15px; margin-top:8px; text-decoration:none; font-stretch:10px; padding:5px;">
  <br><textarea name="comments" placeholder="&nbsp;&nbsp;Leave Comments Here..." 
			style="width:500px; height:95px; background:white; text-indent;10px;  
			border:2px solid #686E73;border-radius:15px; margin-top:8px; padding:5px; font-stretch:10px;"></textarea>
  <input type="submit" name="submit" style="value:none; background:transparent url('red.png');
  width:50px; height:50px; border:none; color:transparent; margin-top:-20px; margin-left:-5px;">
  </form>
  
		</div>
		</div>
		
		<input class="modal-state" id="modal-2" type="checkbox" />
<div class="modal">
  <label class="modal__bg" for="modal-2"></label>
  <div class="modal__inner">
    <label class="modal__close" for="modal-2"></label>
   
      <h1 style="color:white; font-style:italic; margin-top:-5px;">
	<img src="images/mem2.png" width="50px" height="50px">Members</h1>
	<h3 style="width:100%; height:5px; background:#26FA30; margin-top:-25px;"></h3>
    <div style="background:; width:100%; height:70%;">
	<div>
	<img src="member.png"><p style="margin-left:90px; margin-top:-75px; color:white; font-style:italic;"><span style="font-style:normal; font-weight:bold;">NIRANJAN CHAUDHARY</span><br>
	Batch:2015-19<br>
	Phone No.-83477734119<br>
	E-mail:201552060@iiitvadodara.ac.in
	</p>
	
	</div>
	<div style="margin-left:330px; margin-top:-90px;">
	<img src="member.png"><p style="margin-left:90px; margin-top:-75px; color:white; font-style:italic;"><span style="font-style:normal; font-weight:bold;">ANJAN SRIVATHSAV
</span><br>
	Batch:2015-19<br>
	Phone No.-9492638145<br>
	E-mail:201551048@iiitvadodara.ac.in
	</p>
	
	</div>
	<div>
	<img src="member.png"><p style="margin-left:90px; margin-top:-75px; color:white; font-style:italic;"><span style="font-style:none; font-weight:bold;">VISHAL RAMAN
</span><br>
	Batch:2014-18<br>
	Phone No.-8869925101<br>
	E-mail:201452003@iiitvadodara.ac.in
	</p>
	
	</div>
	<div style="margin-left:330px; margin-top:-90px;">
	<img src="member.png"><p style="margin-left:90px; margin-top:-75px; color:white; font-style:italic;"><span style="font-style:normal; font-weight:bold;">KRISHNANUNNI

</span><br>
	Batch:2014-18<br>
	Phone No.-9909651370<br>
	E-mail:201451055@iiitvadodara.ac.in
	</p>
	
	</div>
	<div>
	<img src="member.png"><p style="margin-left:90px; margin-top:-75px; color:white; font-style:italic;"><span style="font-style:normal; font-weight:bold;">VIVEK KUMAR SINGH
 </span><br>
	Batch:2013-17<br>
	Phone No.-8090059018<br>
	E-mail:201352015@iiitvadodara.ac.in
	</p>
	
	</div>
	<div style="margin-left:330px; margin-top:-90px;">
	<img src="member.png"><p style="margin-left:90px; margin-top:-75px; color:white; font-style:italic;"><span style="font-style:normal; font-weight:bold;">NAWAB SIR
</span><br>
	Batch:2015-19<br>
	Phone No.-949263XXXX<br>
	E-mail:201551048@iiitvadodara.ac.in
	</p>
	
	</div>
	</div>
  </div>
</div>

</body>
</html>