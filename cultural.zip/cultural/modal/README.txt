A Pen created at CodePen.io. You can find this one at http://codepen.io/ShadyAlzayat/pen/LEDJg.

 I'm using labels as a triggers for checkbox which state indicates visibility of modal box.