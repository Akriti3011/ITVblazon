<html>
<head>
<title>Photography Club</title>
<link rel="stylesheet" href="photo.css">
 <script src="http://code.jquery.com/jquery-3.0.0.min.js"></script>
    <script src="quotespinner.js"></script>
</head>
<body>
<div id="logo">
</div>
<div id="film">
<div style="width:1280px; height:100px;background:white;
 margin-top:26px; margin-left:20px;">
 <marquee behavior="alternate">
 <a href="1.jpg"><img src="1.jpg"></a>
 <a href="2.jpg"><img src="2.jpg"></a>
  <a href="3.jpg"><img src="3.jpg"></a>
  <a href="4.jpg"><img src="4.jpg"></a>
  <a href="5.jpg"><img src="5.jpg"></a>
  <a href="6.jpg"><img src="6.jpg"></a>
  <a href="7.jpg"><img src="7.jpg"></a>
  <a href="10.jpg"><img src="10.jpg"></a>
  <a href="11.jpg"><img src="11.jpg"></a>
  <a href="12.jpg"><img src="12.jpg"></a>
  <a href="13.jpg"><img src="13.jpg"></a>
  <a href="14.jpg"><img src="14.jpg"></a>
 </marquee>
</div>
</div>
<div class="tab">
<a href="gallery2/index.html"><img src="a.png" width="300px" height="100px"></a><br>
<label class="btn" for="modal-1" id="feed"><img src="b.png" width="300px" height="100px"></label>
<label class="btn" for="modal-2" id="feed"><img src="c.png" width="300px" height="100px"></label>
<a href="fileupload/index.php"><img src="d.png" width="300px" height="100px"></a>
</div>
<div class="noti">
<h1 style="text-align:center; font-family:Arabic Typesetting; color:#18B2B8; font-size:260%;">Notification</h1>
<div class="quotes">
      
      <div class="quote-contain">
        <div class="quote-rotate">
          <p>&ldquo;On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee.&rdquo;</p>
        </div>
        <div class="quote-rotate">
          <p>&ldquo;But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness. . &rdquo;</p>
        </div>
        <div class="quote-rotate">
          <p>&ldquo;Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure.  .&rdquo;</p>
        </div>
        <div class="quote-rotate">
          <p>&ldquo;The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words. . .&rdquo;</p>
        </div>
		
      </div>
     
    </div><script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-36251023-1']);
  _gaq.push(['_setDomainName', 'jqueryscript.net']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>

</div>
<div class="quote-dots"></div>
 </div>


<input class="modal-state" id="modal-1" type="checkbox" />
<div class="modal">
  <label class="modal__bg" for="modal-1"></label>
  <div class="modal__inner">
    <label class="modal__close" for="modal-1"></label>
      <h1 style="color:white; font-style:italic; margin-top:-5px;">
	Queries</h1>
	<h3 style="width:100%; height:5px; background:orange; margin-top:-20px;"></h3>
    <form action="#" method="post">
	<input type="text" name="name" placeholder="&nbsp;&nbsp;Enter your name" required="required" style="width:300px; border:2px solid #686E73;
	height:35px; background:white; border-radius:15px; text-decoration:none; font-stretch:10px; padding:5px;">
  <br><input type="text" name="id" placeholder="&nbsp;&nbsp;Enter your ID" style="width:300px; border:2px solid #686E73;
	height:35px; background:white; border-radius:15px; margin-top:8px; text-decoration:none; font-stretch:10px; padding:5px;">
  <br><textarea name="comments" placeholder="&nbsp;&nbsp;Leave Comments Here..." 
			style="width:500px; height:95px; background:white; text-indent;10px;  
			border:2px solid #686E73;border-radius:15px; margin-top:8px; padding:5px; font-stretch:10px;"></textarea>
  <input type="submit" name="submit" style="value:none; background:transparent url('red.png');
  width:50px; height:50px; border:none; color:transparent; margin-top:-20px; margin-left:-5px;">
  </form>
  </div>
  </div>
  
  <input class="modal-state" id="modal-2" type="checkbox" />
<div class="modal">
  <label class="modal__bg" for="modal-2"></label>
  <div class="modal__inner">
    <label class="modal__close" for="modal-2"></label>
   
      <h1 style="color:white; font-style:italic; margin-top:-5px;">
	Members</h1>
	<h3 style="width:100%; height:5px; background:#26FA30; margin-top:-25px;"></h3>
    <div style="background:; width:100%; height:70%;">
	<div>
	
	</div>
  </div>
  
</body>
</html>