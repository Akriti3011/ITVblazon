
<?php
session_start();

?>


<?php
require("db/db.php");
if(isset($_POST['submit'])){
$name = $_POST['name'];
$name1 = $_POST['name1'];
$comments = $_POST['comments'];

{
mysqli_query($con, "INSERT INTO comments(name,name1,comments,clubs_comm_id) VALUES('$name','$name1','$comments','C9')");

}

}
mysqli_close($con);
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>IIITV MESS</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
 

<link href="tooplate_style.css" rel="stylesheet" type="text/css" />
<script src="quotespinner.js"></script>
<script src="http://code.jquery.com/jquery-3.0.0.min.js"></script>
<script type="text/JavaScript" src="js/jquery-1.6.3.js"></script> 

<link rel="stylesheet" type="text/css" href="css/ddsmoothmenu.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script type="text/javascript" src="js/ddsmoothmenu.js">



</script>

<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "tooplate_menu", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>

<link rel="stylesheet" href="css/slimbox2.css" type="text/css" media="screen" /> 
<script type="text/JavaScript" src="js/slimbox2.js"></script> 

<link rel="stylesheet" href="css/nivo-slider.css" type="text/css" media="screen" />
 <script src="sliderengine/jquery.js"></script>
    <script src="sliderengine/amazingslider.js"></script>
    <link rel="stylesheet" type="text/css" href="sliderengine/amazingslider-1.css">
    <script src="sliderengine/initslider-1.js"></script>
  
</head>

<style>
div.img1 {
    margin-left: 100px;
    border: 3px solid #152238;
    width: 200px;
    float: left;
    margin-top: 50px;
}

div.img1:hover {
    border: 3px solid #777;
}

div.img1 img {
    width: 100%;
    height: 55%;
}

div.desc1 {
    padding: 15px;
    text-align: center;
    font-size: 18px;
    color: white;
    font-family: "Arial";
    background-color: #152238;
}
</style>
<body>

<div id="tooplate_header">
    <a href="index.html" class="sitetitle"><span style="font-size:60px; font-family:French Script MT; color:white;">
	mess</span>&nbsp;&nbsp;&nbsp;&nbsp;
	<span style="font-size:50px; font-family:Bauhaus 93; color:white;">
	Committee</span>
	
	</a>  
    <div id="tooplate_menu" class="ddsmoothmenu">
        <ul>
            <li><a href="../home/index.php" >Home</a></li>
            <li><a href="menu.html">Mess Menu</a>
                
            </li>
            <li><a href="#feed">Feedback</a>
                
            </li>
            <li><a href="#">About</a></li>                
            <li class="last"><a href="alert/alertlogin.php" class="last">Alert</a></li>
        </ul>
        <br style="clear: left" />
    </div> <!-- end of tooplate_menu -->      
</div> <!-- END of header -->
<div id="tooplate_slider_wrapper">
    <div id="tooplate_slider">
    	<div class="slider-wrapper theme-default">
            <div id="slider" class="nivoSlider">
                <img src="images/slider/01.jpg" alt="" title="#caption1" />
                <img src="images/slider/02.jpg" alt="" title="#caption2" />
                 <img src="images/slider/03.jpg" alt="" title="#caption3" />
                <img src="images/slider/04.jpg" alt="" title="#caption4" /> 
				<img src="images/slider/01.jpg" alt="" title="#caption5" /> 
				<img src="images/slider/03.jpg" alt="" title="#caption6" /> 
				<img src="images/slider/04.jpg" alt="" title="#caption7" /> 				
            </div>
            <div id="caption1" class="nivo-html-caption">
            	<h1 style="margin-top:-60px;margin-left:-150px;">Monday</h1>
                <p><b>Breakfast :</b> Puri Sabzi<br><b>Lunch :</b> Roti Mix-Veg Masala Bhindi Dal Makhani Jeera Rice Salad Lassi Papad<br><b>Snacks :</b> Manchurian Cold coffee Banana <br><b> Dinner :</b> Roti Paneer-Butter Masala Dhoodhi Chana Mix Dal Rice Salad Dahi vada Papad</p>
			</div>
            <div id="caption2" class="nivo-html-caption">
                <h1 style="margin-top:-60px;margin-left:-150px;">Tuesday</h1>
                <p><b>Breakfast :</b> Masala Idli<br><b>Lunch :</b> Roti Chole Gwar Phali Chana Dal Jeera Rice Salad Chaas Fryums<br><b>Snacks :</b> Manchurian Cold coffee Banana <br><b> Dinner :</b> Roti Paneer-Butter Masala Dhoodhi Chana Mix Dal Rice Salad Dahi vada Papad</p>
            </div>
            <div id="caption3" class="nivo-html-caption">
                <h1 style="margin-top:-60px;margin-left:-150px;">Wednesday</h1>
                <p><b>Breakfast :</b> Puri Sabzi<br><b>Lunch :</b> Roti Mix-Veg Masala Bhindi Dal Makhani Jeera Rice Salad Lassi Papad<br><b>Snacks :</b> Manchurian Cold coffee Banana <br><b> Dinner :</b> Roti Paneer-Butter Masala Dhoodhi Chana Mix Dal Rice Salad Dahi vada Papad</p></div>
			</div>
			<div id="caption4" class="nivo-html-caption">
            	<h1 style="margin-top:-60px;margin-left:-150px;">thursday</h1>
                <p><b>Breakfast :</b> Puri Sabzi<br><b>Lunch :</b> Roti Mix-Veg Masala Bhindi Dal Makhani Jeera Rice Salad Lassi Papad<br><b>Snacks :</b> Manchurian Cold coffee Banana <br><b> Dinner :</b> Roti Paneer-Butter Masala Dhoodhi Chana Mix Dal Rice Salad Dahi vada Papad</p>
            </div>
            <div id="caption5" class="nivo-html-caption">
                <h1 style="margin-top:-60px;margin-left:-150px;">Friday</h1>
                <p><b>Breakfast :</b> Puri Sabzi<br><b>Lunch :</b> Roti Mix-Veg Masala Bhindi Dal Makhani Jeera Rice Salad Lassi Papad<br><b>Snacks :</b> Manchurian Cold coffee Banana <br><b> Dinner :</b> Roti Paneer-Butter Masala Dhoodhi Chana Mix Dal Rice Salad Dahi vada Papad</p></div>
            </div>
            <div id="caption6" class="nivo-html-caption">
                <h1 style="margin-top:-60px;margin-left:-150px;">Saturday</h1>
                <p><b>Breakfast :</b> Puri Sabzi<br><b>Lunch :</b> Roti Mix-Veg Masala Bhindi Dal Makhani Jeera Rice Salad Lassi Papad<br><b>Snacks :</b> Manchurian Cold coffee Banana <br><b> Dinner :</b> Roti Paneer-Butter Masala Dhoodhi Chana Mix Dal Rice Salad Dahi vada Papad</p></div>
			</div>
			<div id="caption7" class="nivo-html-caption">
                <h1 style="margin-top:-60px;margin-left:-150px;">Sunday</h1>
                <p><b>Breakfast :</b> Puri Sabzi<br><b>Lunch :</b> Roti Mix-Veg Masala Bhindi Dal Makhani Jeera Rice Salad Lassi Papad<br><b>Snacks :</b> Manchurian Cold coffee Banana <br><b> Dinner :</b> Roti Paneer-Butter Masala Dhoodhi Chana Mix Dal Rice Salad Dahi vada Papad</p>
            </div>
        <div class="button_box">
        	
        </div>
        <script type="text/javascript" src="js/jquery-1.6.3.min.js"></script>
		<script type="text/javascript" src="js/jquery.nivo.slider.pack.js"></script>
        <script type="text/javascript">
        $(window).load(function() {
            $('#slider').nivoSlider({
			effect: 'fade',
			controlNav: false, // 1,2,3... navigation
            directionNav: false,
			animSpeed: 1200, // Slide transition speed
	        pauseTime: 3000, // How long each slide will show
			});
        });
        </script>	
    </div> <!-- END of slider -->
</div>
<!--<div id="tooplate_main">
    	<div id="home_about">
        	<h1>Mess Menu</h1>
			</div>
			<div style="width:1200px; margin-left:-140px; height:800px; postion:fixed;
			background:;">
			<iframe style="width:1200px;height:750px; background:transparent;" src="menu.html"></iframe>
			</div>
        
       

<div id="tooplate_copyright_wrapper">
    <div id="tooplate_copyright">
        Copyright © ITV BLAZON  2016
  
    </div>
</div> -->

<div style="width:100%; height:400px; background:url('2.jpg'); margin-top:-50px; color:white;">
<img src="4.png" width="200px" height="350px" style="margin-top:20px; postion:absolute;">
<img src="6.jpg" style="float:right; margin-right:10px; position:relative;margin-top:60px;">
<p style="width:700px; height:300px; margin-top:-100px;margin-left:200px;position:absolute; margin-top:-300px; font-size:15px;">Another important part of any student’s life is food. The IIITV mess provides healthy meals during the year for the residential students.
<br>
The Mess Committee akriti MessComm facilitates the various functions in the mess. MessComm provides the mess manager with the weekly menu consisting of nutritional meals for breakfast, lunch and dinner. MessComm also coordinates the Executive dinner every month on the basis of a specific theme such as south Indian or Punjabi etc.
<br>
MessComm provides special meals for various festivals and communicates the requests of the students to the mess manager. MessComm also coordinates the meals for various conclaves in association with the organising committee of the respective conclave.
<br>
The sole motive of this committee is to make good quality food available to students and make them realise the importance of food availability by encouraging them not to waste food. The other motive of this committee is to break the monotonicity of the menu and introducing new cuisines.
<h2 style="font-style:italic;color:orange; text-align:center; margin-top:-70px;">"One cannot think well, love well, sleep well,<br> if one has not dined well." </h2>

</p>
</div>

<div style="width:100%; height:400px; background:url('3.jpg'); margin-top:0px;">

 <div class="img1">
    <img src="11.jpg" alt="Trolltunga Norway" width="300" height="200">
  <div class="desc1">YASH CHOUBEY<br><i class="fa fa-phone"></i> 9460064512</div>
</div>

<div class="img1">
    <img src="12.jpg" alt="Forest" width="300" height="200">
  <div class="desc1">SHARAD PATEL<br><i class="fa fa-phone"></i> 8128268037</div>
</div>

<div class="img1">
    <img src="13.jpg" alt="Northern Lights" width="300" height="200">
  <div class="desc1">DEEPAK GOYAL<br><i class="fa fa-phone"></i> 7575053163</div>
</div>

<div class="img1">
    <img src="14.jpg" alt="Mountains" width="300" height="200">
  <div class="desc1">AKRITI BHADORIYA<br><i class="fa fa-phone"></i> 7285832105</div>
</div>



</div>
<script src="js/scroll-startstop.events.jquery.js" type="text/javascript"></script>
<script type="text/javascript">
	$(function() {
		var $elem = $('#content');
		
		$('#nav_up').fadeIn('slow');
		
		$(window).bind('scrollstart', function(){
			$('#nav_up,#nav_down').stop().animate({'opacity':'0.2'});
		});
		$(window).bind('scrollstop', function(){
			$('#nav_up,#nav_down').stop().animate({'opacity':'1'});
		});
		
		$('#nav_up').click(
			function (e) {
				$('html, body').animate({scrollTop: '0px'}, 800);
			}
		);
	});
</script>
<div style="width:100%;height:300px; background-image:url('7.png');margin-top:px; text-align:center;
		padding:2px;">
		<label class="btn" for="modal-1" id="feed">Feedback</label>
		</div>
		<div style="width:30px; height:250px; background:url('images/cont.jpg'); color:white; text-align:vertical; margin-top:-275px; border-radius:4px;" id="contact">
		</div>
		<div style="width:400px; height:250px; background:; margin-left:480px; margin-top:-240px;">
		
		
		
		<iframe style="width:400px;height:250px; background:white;" src="logs.php" id="frame"></iframe>		
		
		
		
		</div>
		
		
		
		
		
		
		</div>
		<div style="width:300px; height:250px; background:; margin-left:100px; margin-top:-255px;">
		<h2 style="color:white; text-align:center;">Mess Committee Enquiry</h2>
		<img src="loc1.png" width="25px" height="25px" style="margin-left:20px;margin-top:-15px;">
		<p style="color:white; margin-left:54px; margin-top:-25px;">
		 Address: IIIT Vadodara<br>GEC Block-09 IC Department,Sector 28 <br>Gandhinagar.382028
		<br><span style="color:white; font-size:120%;">Phone No.-7567775854</span>
		</p>
		<img src="mail.png" width="25px" height="25px" style="margin-left:20px;margin-top:-px;">
		<p style="color:white; margin-left:54px; margin-top:-25px;">
		mess@iiitvadodara.ac.in
		</p>
		</div>
       
	   <div style="width:300px; height:250px; background:; margin-left:950px; margin-top:-245px; color:orange;">
		<h2 style="color:white; text-align:center;">Notifications</h2>
		<div class="quotes">
      
      <div class="quote-contain">
        <div class="quote-rotate">
          <p>&ldquo;On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee.&rdquo;</p>
        </div>
       
        <div class="quote-rotate">
          <p>&ldquo;The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words. . .&rdquo;</p>
        </div>
		
      </div>
     
    </div><script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-36251023-1']);
  _gaq.push(['_setDomainName', 'jqueryscript.net']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>

</div>
<div class="quote-dots"></div>
 </div>


			
			
			
<input class="modal-state" id="modal-1" type="checkbox" />
<div class="modal">
  <label class="modal__bg" for="modal-1"></label>
  <div class="modal__inner">
    <label class="modal__close" for="modal-1"></label>
      <h1 style="color:white; font-style:italic; margin-top:-5px;">
	<img src="feed1.png" width="50px" height="50px">Feedback</h1>
	<h3 style="width:100%; height:5px; background:orange; margin-top:-30px;"></h3>
    <form action="#" method="post">
	<input type="text" name="name" placeholder="&nbsp;&nbsp;Enter your name" style="width:300px; border:2px solid #686E73;
	height:35px; background:white; border-radius:15px; text-decoration:none; font-stretch:10px; padding:5px;">
  <br><input type="text" name="name1" placeholder="&nbsp;&nbsp;Enter your ID" style="width:300px; border:2px solid #686E73;
	height:35px; background:white; border-radius:15px; margin-top:8px; text-decoration:none; font-stretch:10px; padding:5px;">
  <br><textarea name="comments" placeholder="&nbsp;&nbsp;Leave Comments Here..." 
			style="width:500px; height:65px; background:white; text-indent;10px;  
			border:2px solid #686E73;border-radius:15px; margin-top:8px; padding:5px; font-stretch:10px;"></textarea>
  <input type="submit" name="submit" style="value:none; background:transparent url('red.png');
  width:50px; height:50px; border:none; color:transparent; margin-top:-20px; margin-left:-5px;">
  </form>
		<div></div></div></div>

		
 
</body>
</html>